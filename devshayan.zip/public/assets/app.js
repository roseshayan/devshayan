(() => {
  const items = document.querySelectorAll(".skill");
  if (!items.length) return;
  const run = (el) => {
    const val = Number(el.dataset.value || 0);
    const bar = el.querySelector(".skill-bar");
    if (!bar) return;
    bar.style.transition = "width 900ms ease";
    bar.style.width = Math.max(0, Math.min(100, val)) + "%";
  };
  const io = new IntersectionObserver(
    (entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          run(e.target);
          io.unobserve(e.target);
        }
      });
    },
    { threshold: 0.35 }
  );
  items.forEach((el) => io.observe(el));
})();
