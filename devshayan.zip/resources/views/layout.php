<?php

declare(strict_types=1);
function e(mixed $v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}
?>
<!doctype html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title ?? 'Website') ?></title>
    <link rel="stylesheet" href="/assets/app.css">
</head>

<body class="bg-white text-slate-900">
    <?= $content ?? '' ?>
    <script src="/assets/app.js"></script>
</body>

</html>