<?php

declare(strict_types=1); ?>
<div class="max-w-6xl mx-auto px-4 py-8">
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <main class="lg:col-span-8">
            <section class="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
                <div class="order-2 md:order-1">
                    <div class="text-sm text-slate-500">Hello, I'm</div>
                    <h1 class="text-3xl md:text-4xl font-bold"><?= e($data['name']) ?></h1>
                    <div class="text-slate-600 mt-1"><?= e($data['headline']) ?></div>
                    <p class="text-slate-600 mt-4 leading-7 max-w-xl"><?= e($data['about']) ?></p>
                </div>
                <div class="order-1 md:order-2 flex justify-start md:justify-end">
                    <div class="w-40 h-40 md:w-56 md:h-56 rounded-full bg-slate-200 overflow-hidden ring-8 ring-slate-50">
                        <img src="https://placehold.co/400x400" alt="profile" class="w-full h-full object-cover">
                    </div>
                </div>
            </section>

            <section class="mt-12">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-[2px] bg-slate-200"></div>
                    <h2 class="text-xl font-semibold">Prof. Skill</h2>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mt-6">
                    <div class="space-y-4">
                        <?php foreach ($data['skills_left'] as $s): ?>
                            <div class="skill" data-value="<?= (int)$s['value'] ?>">
                                <div class="flex justify-between text-sm text-slate-600">
                                    <span><?= e($s['title']) ?></span><span><?= (int)$s['value'] ?>%</span>
                                </div>
                                <div class="h-2 bg-slate-100 rounded-full overflow-hidden mt-2">
                                    <div class="skill-bar h-2 bg-slate-700 rounded-full w-0"></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="space-y-4">
                        <?php foreach ($data['skills_right'] as $s): ?>
                            <div class="skill" data-value="<?= (int)$s['value'] ?>">
                                <div class="flex justify-between text-sm text-slate-600">
                                    <span><?= e($s['title']) ?></span><span><?= (int)$s['value'] ?>%</span>
                                </div>
                                <div class="h-2 bg-slate-100 rounded-full overflow-hidden mt-2">
                                    <div class="skill-bar h-2 bg-slate-700 rounded-full w-0"></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </section>

            <section class="mt-12">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-[2px] bg-slate-200"></div>
                    <h2 class="text-xl font-semibold">Journey</h2>
                </div>
                <div class="mt-6 border-r border-slate-200 pr-6 space-y-8">
                    <?php foreach ($data['journey'] as $j): ?>
                        <div class="relative">
                            <div class="absolute -right-[29px] top-1 w-3 h-3 rounded-full bg-slate-700"></div>
                            <div class="text-sm text-slate-500"><?= e($j['year']) ?></div>
                            <div class="font-semibold mt-1"><?= e($j['title']) ?></div>
                            <div class="text-slate-600 mt-1 leading-7"><?= e($j['desc']) ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <section class="mt-12">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-[2px] bg-slate-200"></div>
                    <h2 class="text-xl font-semibold">Education</h2>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                    <?php foreach ($data['education'] as $ed): ?>
                        <div class="p-5 rounded-2xl border border-slate-200">
                            <div class="text-sm text-slate-500"><?= e($ed['range']) ?></div>
                            <div class="font-semibold mt-1"><?= e($ed['title']) ?></div>
                            <div class="text-slate-600 mt-1"><?= e($ed['place']) ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
        </main>

        <aside class="lg:col-span-4">
            <div class="lg:sticky lg:top-8 space-y-8">
                <section class="p-6 rounded-2xl border border-slate-200">
                    <div class="flex items-center justify-between">
                        <h3 class="font-semibold">Bio</h3>
                        <div class="text-xs text-slate-400 rotate-90 select-none">Bio</div>
                    </div>
                    <div class="mt-4 space-y-3 text-sm">
                        <?php foreach ($data['bio'] as $k => $v): ?>
                            <div class="flex justify-between gap-4">
                                <span class="text-slate-500"><?= e($k) ?>:</span>
                                <span class="text-slate-700 text-left"><?= e($v) ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </section>

                <section class="p-6 rounded-2xl border border-slate-200">
                    <div class="flex items-center justify-between">
                        <h3 class="font-semibold">Contact</h3>
                        <div class="text-xs text-slate-400 rotate-90 select-none">Contact</div>
                    </div>
                    <div class="mt-4 space-y-3 text-sm">
                        <?php foreach ($data['contact'] as $k => $v): ?>
                            <div class="flex justify-between gap-4">
                                <span class="text-slate-500"><?= e($k) ?>:</span>
                                <span class="text-slate-700 text-left"><?= e($v) ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </section>

                <section class="p-6 rounded-2xl border border-slate-200">
                    <h3 class="font-semibold"><?= e($data['ref']['title']) ?></h3>
                    <div class="text-sm text-slate-600 mt-2"><?= e($data['ref']['name']) ?></div>
                    <div class="text-sm text-slate-600 mt-1"><?= e($data['ref']['email']) ?></div>
                </section>
            </div>
        </aside>
    </div>
</div>