<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\View;

final class HomeController
{
    public function index(): string
    {
        // داده‌ها فعلاً ثابت؛ بعداً می‌بریم به DB یا پنل ادمین
        $data = [
            'name' => 'Shayan Namayandeh',
            'headline' => 'PHP / Front-end / Wordpress Developer',
            'about' => '
            Web developer with 4+ years of experience building production websites and internal systems using JavaScript (ES6+),
            HTML/CSS, PHP, MySQL, and REST APIs. Strong fundamentals in DOM, responsive UI, and performance optimization (80%+
            load-time improvements). Experienced instructor/mentor. Currently preparing for modern front-end stack (React + TypeScript)
            and seeking to grow into a professional front-end engineer through Divar’s Front-End Engineering Bootcamp.
            ',
            'skills_left' => [
                ['title' => 'JavaScript (ES6+)', 'value' => 85],
                ['title' => 'HTML & CSS', 'value' => 95],
                ['title' => 'PHP & MySQL', 'value' => 85],
                ['title' => 'Bootstrap', 'value' => 98],
                ['title' => 'jQuery', 'value' => 90],
                ['title' => 'MySQL', 'value' => 80],
                ['title' => 'Figma/Adobe XD', 'value' => 65],
            ],
            'skills_right' => [
                ['title' => 'OOP & MVC', 'value' => 80],
                ['title' => 'Git', 'value' => 98],
                ['title' => 'WordPress', 'value' => 95],
                ['title' => 'Responsive UI', 'value' => 85],
                ['title' => 'Flutter', 'value' => 70],
                ['title' => 'REST API', 'value' => 90],
                ['title' => 'Arduino/OpenCV', 'value' => 60],
            ],
            'bio' => [
                'Birthday' => '2001 December 25, Tuesday',
                'Nationality' => 'Iranian',
                'Languages' => 'Farsi, English, Turkish',
            ],
            'contact' => [
                'Github' => 'github.com/roseshayan',
                'LinkedIn' => 'linkedin.com/in/shayan-namayandeh',
                'Telegram' => 't.me/SudoShayanNA',
                'Email' => 'namayandeshayan@gmail.com',
                'Website' => 'doroosamooz.ir',
            ],
            'journey' => [
                ['year' => '2020', 'title' => 'شروع مسیر', 'desc' => 'یک توضیح کوتاه...'],
                ['year' => '2022', 'title' => 'پروژه/شغل مهم', 'desc' => 'یک توضیح کوتاه...'],
                ['year' => '2024', 'title' => 'رشد و دستاورد', 'desc' => 'یک توضیح کوتاه...'],
            ],
            'education' => [
                ['range' => '2014-2018', 'title' => 'BSc Electrical Engineering', 'place' => '—'],
                ['range' => '2018-2022', 'title' => '—', 'place' => '—'],
            ],
            'ref' => [
                'title' => 'Ref',
                'name' => 'Developed by Shayan',
                'email' => 'namayandeshayan@gmail.com',
            ],
        ];
        return View::render('home', ['data' => $data, 'title' => 'Personal Website']);
    }
}
